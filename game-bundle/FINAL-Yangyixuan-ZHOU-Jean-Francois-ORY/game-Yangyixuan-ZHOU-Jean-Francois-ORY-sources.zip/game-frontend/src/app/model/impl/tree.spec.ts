import { Tree } from './tree';

describe('Tree', () => {
  it('should create an instance', () => {
    expect(new Tree()).toBeTruthy();
  });
});
