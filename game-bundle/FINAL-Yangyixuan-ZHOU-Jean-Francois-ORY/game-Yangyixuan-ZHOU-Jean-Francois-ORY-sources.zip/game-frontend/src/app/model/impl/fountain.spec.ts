import { Fountain } from './fountain';

describe('Fountain', () => {
  it('should create an instance', () => {
    expect(new Fountain()).toBeTruthy();
  });
});
