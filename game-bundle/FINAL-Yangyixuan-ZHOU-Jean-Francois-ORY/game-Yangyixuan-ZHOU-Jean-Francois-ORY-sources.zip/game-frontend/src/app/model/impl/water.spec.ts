import { Water } from './water';

describe('Water', () => {
  it('should create an instance', () => {
    expect(new Water()).toBeTruthy();
  });
});
