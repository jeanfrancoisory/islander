import { Circus } from './circus';

describe('Circus', () => {
  it('should create an instance', () => {
    expect(new Circus()).toBeTruthy();
  });
});
