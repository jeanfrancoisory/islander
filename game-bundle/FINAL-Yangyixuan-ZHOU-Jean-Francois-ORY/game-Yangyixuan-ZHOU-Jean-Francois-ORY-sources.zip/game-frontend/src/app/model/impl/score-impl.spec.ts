import { ScoreImpl } from './score-impl';

describe('ScoreImpl', () => {
  it('should create an instance', () => {
    expect(new ScoreImpl()).toBeTruthy();
  });
});
