import { WindTurbine } from './wind-turbine';

describe('WindTurbine', () => {
  it('should create an instance', () => {
    expect(new WindTurbine()).toBeTruthy();
  });
});
