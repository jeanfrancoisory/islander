import { GameImpl } from './game-impl';

describe('GameImpl', () => {
  it('should create an instance', () => {
    expect(new GameImpl()).toBeTruthy();
  });
});
