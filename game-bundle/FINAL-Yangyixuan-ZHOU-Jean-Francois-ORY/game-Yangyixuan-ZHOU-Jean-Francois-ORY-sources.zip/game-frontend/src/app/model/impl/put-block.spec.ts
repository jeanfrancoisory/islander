import { PutBlock } from './put-block';

describe('PutBlock', () => {
  it('should create an instance', () => {
    expect(new PutBlock()).toBeTruthy();
  });
});
