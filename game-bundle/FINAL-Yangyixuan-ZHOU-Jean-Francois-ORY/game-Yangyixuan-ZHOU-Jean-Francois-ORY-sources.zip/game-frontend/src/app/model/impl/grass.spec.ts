import { Grass } from './grass';

describe('Grass', () => {
  it('should create an instance', () => {
    expect(new Grass()).toBeTruthy();
  });
});
