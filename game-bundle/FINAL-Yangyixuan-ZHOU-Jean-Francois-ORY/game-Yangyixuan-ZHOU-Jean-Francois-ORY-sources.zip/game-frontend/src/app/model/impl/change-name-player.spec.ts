import { ChangeNamePlayer } from './change-name-player';

describe('ChangeNamePlayer', () => {
  it('should create an instance', () => {
    expect(new ChangeNamePlayer()).toBeTruthy();
  });
});
