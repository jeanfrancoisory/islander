import { PlayerImpl } from './player-impl';

describe('PlayerImpl', () => {
  it('should create an instance', () => {
    expect(new PlayerImpl()).toBeTruthy();
  });
});
