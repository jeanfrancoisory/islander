export interface Commande {
  do(): void;
}
