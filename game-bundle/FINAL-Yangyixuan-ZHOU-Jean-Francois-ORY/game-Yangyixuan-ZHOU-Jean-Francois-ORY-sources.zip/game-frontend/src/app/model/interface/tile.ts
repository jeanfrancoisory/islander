export interface Tile {
  type: string;
  isOccipued: boolean;
}
