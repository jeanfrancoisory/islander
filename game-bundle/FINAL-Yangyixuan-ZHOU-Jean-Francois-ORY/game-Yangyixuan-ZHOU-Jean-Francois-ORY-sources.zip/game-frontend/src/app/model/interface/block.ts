export interface Block {
  clicked: boolean;
}
