export interface Player {
  name: string;
}
